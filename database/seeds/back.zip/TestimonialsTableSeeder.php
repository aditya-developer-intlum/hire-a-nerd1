<?php

use Illuminate\Database\Seeder;

class TestimonialsTableSeeder extends Seeder
{

    /**
     * Auto generated seed file
     *
     * @return void
     */
    public function run()
    {
        

        \DB::table('testimonials')->delete();
        
        \DB::table('testimonials')->insert(array (
            0 => 
            array (
                'id' => 61,
                'name' => 'Prof. Gideon Dooley DDS',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            1 => 
            array (
                'id' => 62,
                'name' => 'Gerson Douglas PhD',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            2 => 
            array (
                'id' => 63,
                'name' => 'Catharine Heaney',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            3 => 
            array (
                'id' => 64,
                'name' => 'Pierre Wisozk',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            4 => 
            array (
                'id' => 65,
                'name' => 'Berry Kovacek',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            5 => 
            array (
                'id' => 66,
                'name' => 'Rylan Koch',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            6 => 
            array (
                'id' => 67,
                'name' => 'Prof. Ethan Runolfsdottir',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            7 => 
            array (
                'id' => 68,
                'name' => 'Tod Spinka',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            8 => 
            array (
                'id' => 69,
                'name' => 'Martine Huels I',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            9 => 
            array (
                'id' => 70,
                'name' => 'Evangeline Olson',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:49:19',
                'updated_at' => '2019-07-08 11:49:19',
            ),
            10 => 
            array (
                'id' => 71,
                'name' => 'Prof. Hayden Zulauf',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            11 => 
            array (
                'id' => 72,
                'name' => 'Thelma Dare',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            12 => 
            array (
                'id' => 73,
                'name' => 'Dallin Brakus',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            13 => 
            array (
                'id' => 74,
                'name' => 'Jeremy Murazik',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            14 => 
            array (
                'id' => 75,
                'name' => 'Shawn Reichel',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            15 => 
            array (
                'id' => 76,
                'name' => 'Mrs. Thea Adams',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            16 => 
            array (
                'id' => 77,
                'name' => 'Brando McKenzie',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            17 => 
            array (
                'id' => 78,
                'name' => 'Prof. Franco D\'Amore V',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            18 => 
            array (
                'id' => 79,
                'name' => 'Emiliano Smitham',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            19 => 
            array (
                'id' => 80,
                'name' => 'Mathias Emmerich',
                'designation' => 'Web Developer',
                'description' => 'Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-07-08 11:50:00',
                'updated_at' => '2019-07-08 11:50:00',
            ),
            20 => 
            array (
                'id' => 82,
                'name' => 'ssssssssssssssssss',
                'designation' => 'sssssssssssssssssssss',
                'description' => 'ssssssssssssssssssssssssssssss',
                'rate' => '1',
                'times' => 0,
                'created_at' => '2019-08-06 10:52:16',
                'updated_at' => '2019-08-06 10:52:16',
            ),
        ));
        
        
    }
}